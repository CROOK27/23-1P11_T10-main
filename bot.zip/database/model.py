"""Модуль для создание БД"""
from peewee import SqliteDatabase, Model, TextField,CharField,ForeignKeyField

db = SqliteDatabase('sqlite.db')

class table(Model):
    """БД"""
    class Meta:
        """БД"""
        database = db

class Groops(table):
    """Группы"""
    groop=CharField(max_length=25)

class User(table):
    """Пользователь"""
    chat_id = TextField()
    name = CharField(max_length=80)
    groop=ForeignKeyField(Groops,backref='Users')
    rang=CharField(max_length=10)

class teacher_or_no(table):
    user=TextField()
    message_id=TextField()

def admin_bot(id,name):
    User.get_or_create(
        chat_id = id,
        name= name,
        groop='1',
        rang='Администратор'
        )
    Groops.get_or_create(
        groop="Администратор"
    )
    Groops.get_or_create(
        groop="Преподаватель"
    )

def start_db():
    """Создание|запуск БД"""
    db.connect()
    db.create_tables([User,Groops,teacher_or_no], safe=True)
    admin_bot(1975886539,'Проходимец')
    db.close()
