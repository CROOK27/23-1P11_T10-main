"""модуль для машинных состояние"""
from aiogram.fsm.state import State, StatesGroup

class USR(StatesGroup):
    """Название машинных состояний"""
    name=State()
    Groops=State()
    groop_ad=State()
