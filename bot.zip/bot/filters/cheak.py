"""Библеотеки для проверки пользователя"""
from aiogram.filters import BaseFilter
from aiogram.types import Message
from database.model import User

class Cheakteacher(BaseFilter):
    """Проверяет является ли пользователь преподователем"""
    async def __call__ (self,message:Message):
        usr_tea=User.get(User.chat_id == message.from_user.id)
        if usr_tea.rang == "Преподаватель":
            return True
        return False

class Cheakstudent(BaseFilter):
    """Проверяет является ли пользователь студентом"""
    async def __call__ (self,message:Message):
        usr_stu=User.get(User.chat_id == message.from_user.id)
        if usr_stu.rang == "Студент":
            return True
        return False
    
class Cheakadmin(BaseFilter):
    """Проверяет является ли пользователь студентом"""
    async def __call__ (self,message:Message):
        usr_stu=User.get(User.chat_id == message.from_user.id)
        if usr_stu.rang == "Администратор":
            return True
        return False