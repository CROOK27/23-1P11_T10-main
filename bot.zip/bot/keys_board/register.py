"""Модуль для создания кнопок"""
from aiogram.types import InlineKeyboardButton,InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder
from database.model import Groops

Keyboard_register = InlineKeyboardMarkup(inline_keyboard=[
    [
    InlineKeyboardButton(text="Преподаватель",callback_data='Преподаватель'),
    InlineKeyboardButton(text="Студент",callback_data='Студент')
    ]])

def groops():
    """Функция для вывода кнопок с группами"""
    keyboard= InlineKeyboardBuilder()
    i=False
    for groop in Groops.select().where(
        Groops.groop.not_in(['Преподаватель', 'Администратор'])).order_by(Groops.groop):

        keyboard.add(InlineKeyboardButton(text=f"{groop.groop}",
            callback_data=f'groop_{groop.groop}'
            ))
        i=True

    if i:
        return keyboard.adjust(2).as_markup()
    return i

def teach_or_not(name):
    """создание кнопок для подтверждения"""
    keyboard= InlineKeyboardMarkup(inline_keyboard=[
    [
        InlineKeyboardButton(text="Подтвердить",callback_data=f'name1_{name}'),
        InlineKeyboardButton(text='Отказать',callback_data=f'name_{name}')
    ]])
    return keyboard
