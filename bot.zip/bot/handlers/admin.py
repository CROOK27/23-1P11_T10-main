"""Модуль обработки команд администратора"""
from aiogram.types import Message, BotCommand
from aiogram.fsm.context import FSMContext
from database.model import Groops
import bot.stater.state as stat

async def menu_admin(message:Message,state:FSMContext) -> None:
    """""
    Функция для вывода меню
    """
    await state.clear()
    # pylint: disable=C0415:
    from main import bot
    commands = [
        BotCommand(command="/groop", description="Создать Группу"),
        BotCommand(command="/menu", description="Меню")
    ]
    await bot.set_my_commands(commands)

async def groop_add(message:Message,state:FSMContext):
    await message.answer("Введите название группы")
    await state.set_state(stat.USR.groop_ad)

async def groop_name(message:Message,state:FSMContext):
    Groops.get_or_create(groop=message.text) 
    await message.answer("Группа добавленна в список групп")
    await state.clear()
